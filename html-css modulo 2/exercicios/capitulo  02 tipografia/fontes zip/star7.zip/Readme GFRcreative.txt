Notes of the author

-Thank you for downloading "STAR7" fonts From GFRcreative

-this is a free font for PERSONAL USE. CANNOT BE USED FOR COMMERCIAL

-if you want to use this font for commercial please buy the license at: https://gfrcreative.com/product/star7/

-Donation: https://paypal.me/GFRcreative
 
-visit our store at https://gfrcreative.com/ and find other fonts

-if you need a special license please contact us at:
gfr.std@gmail.com or hello@gfrcreative.com

-follow us on instagram for updates @gfrcreative_studio

-if you haven't purchased this font according to the license and you use it for any COMMERCIAL purposes, it's form WITHOUT PERMISSION from us. CORPORATE LICENSE will be charged.

thank you


----------------------------------------------------------------------------------------------------

INDONESIA

-mohon luangkan waktu untuk membaca syarat dan ketentuan pengunaan font ini sebelum anda mengunakanya untuk keperluan KOMERSIL

-Dengan menginstall font ini, Anda setuju untuk terikat oleh persyaratan dan peraturan yang kami berikan

-ini adalah font gratis untuk PENGUNAAN PRIBADI. TIDAK BOLEH DIGUNAKAN UNTUK KOMERSIL

-jika anda ingin mengunakan font ini untuk komersial silahkan membeli lisensinya di: https://gfrcreative.com/product/star7/

-Donasi: https://paypal.me/GFRcreative

-kunjungi toko kami di https://gfrcreative.com/ dan temukan font yang lainya

-jika anda memerlukan lisensi khusus silahkan hubungi kami di:
gfr.std@gmail.com atau hello@gfrcreative.com

-ikuti kami di instagram untuk update @gfrcreative_studio

-jika anda belum membeli font ini sesuai lisensi dan anda mengunakannya untuk keperluan KOMERSIL apapun itu bentuknya TANPA IZIN dari kami. akan dikenakan biaya CORPORATE LICENSE.

terimakasih
